package bvsk.APIDriverScript;

import bvsk.JSONUtils.JSONUtils;

public class DriverScript extends JSONUtils
{
	public static String GET_URL="https://api.tmsandbox.co.nz/v1/Categories/6327/Details.json?catalogue=false";
	public static String valPoint1="Name";
	public static String valPoint2="CanRelist";
	public static String eValue1="Carbon credits";
	public static Boolean eValue2=true;
	public static String eValue3="";
	public static String valPoint3="Promotions";
	public static String val1="Gallery";
	public static String val2="Description";
	public static String val3="2x larger image";
	
	public static void main(String[] args) throws Exception
	{
		JSONUtils util=new JSONUtils();
		//To trigger get Request
		util.sendGET(GET_URL);
		//Parse the response & validate for Name
		util.parseResponse(tResponse,valPoint1);
		  System.out.println("Actual value: "+JSONUtils.actValue);
		  System.out.println("Expected value: "+eValue1);
		  util.validateResults(eValue1,JSONUtils.actValue);//compare expected with Actual for validation1
		  
		//Parse the response & validate for CanRelist
		  util.parseResponse(tResponse,valPoint2);
		  System.out.println("Actual value: "+JSONUtils.actValue1);
		  System.out.println("Expected value: "+eValue2.toString());
		  util.validateResults(eValue2,JSONUtils.actValue1);//compare expected for CanRelist
		//Parse the response & validate for Promotions
		  util.parseResponse(tResponse,valPoint3);
		 
	}
}


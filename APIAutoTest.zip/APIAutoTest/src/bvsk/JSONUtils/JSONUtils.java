package bvsk.JSONUtils;


	import java.io.BufferedReader;
	import java.io.FileReader;
	import java.io.IOException;
	import java.io.InputStreamReader;
	import java.net.HttpURLConnection;
	import java.net.URL;
	
	import org.json.simple.JSONArray;
	import org.json.simple.JSONObject;
	import org.json.simple.parser.JSONParser;
	import org.json.simple.parser.ParseException;

import bvsk.APIDriverScript.DriverScript;




	public class JSONUtils
	{
		public static JSONObject jsonObject = null;
		FileReader input = null;
	    BufferedReader br = null;
	    public static String tRequest;
	    public static String tResponse;
	    public static String actValue;
	    public static Boolean actValue1;
	    
	    
	  //To trigger GET request
		 public void sendGET(String URL) throws IOException {
				URL obj = new URL(URL);
				HttpURLConnection con = (HttpURLConnection) obj.openConnection();
				con.setRequestMethod("GET");
				int responseCode = con.getResponseCode();
				System.out.println("GET Response Code :: " + responseCode);
				if (responseCode == HttpURLConnection.HTTP_OK) { // success
					BufferedReader in = new BufferedReader(new InputStreamReader(
							con.getInputStream()));
					String inputLine;
					StringBuffer response = new StringBuffer();

					while ((inputLine = in.readLine()) != null) {
						response.append(inputLine);
					}
					in.close();

					// print result
					tResponse=response.toString();
					//System.out.println(tResponse);
				} else {
					System.out.println("GET request FAIL");
				}

			}

	    
	   
	
		
		
		 //To parse the response & extract actual value for validations
		 public void parseResponse(String response,String val) throws IOException{
			  //Parse JSON
			  JSONParser jsonparser=new JSONParser();
			  Object jobject;
			try {
				jobject = jsonparser.parse(response);
			  jsonObject = (JSONObject) jobject;
			  if(jsonObject.get(val) instanceof JSONObject || jsonObject.get(val) instanceof String)
			  {
				  actValue=jsonObject.get(val).toString();
			  }
			  else if(jsonObject.get(val) instanceof Boolean)
			  {
				   actValue1=(Boolean) jsonObject.get(val);
				  System.out.println("bool");
			  }
			  else if(jsonObject.get(val) instanceof JSONArray)
			  {
				  JSONArray jsonarr=(JSONArray) jsonObject.get(val);
				  jsonArrayParsar(jsonarr,DriverScript.val1,DriverScript.val2,DriverScript.val3);
			  }
				  
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 public void jsonArrayParsar(JSONArray jarr,String value1,String value2, String value3)
		 {
			  System.out.println("JSON Array Parsing");  
				 
				 for(int i=0;i<jarr.size();i++)
				 {
					 //System.out.println(jarr.size());
					 JSONObject jsonobj = (JSONObject)jarr.get(i);
					 System.out.println(jsonobj);
					 if(jsonobj.get("Name").equals(value1))
					 {
						 System.out.println("Gallery");
						 System.out.println("Description");
						 if(jsonobj.get(value2).toString().contains(value3))
						 {
							 System.out.println("2x larger image found");
						 }
						 break;
					}

				 }
		
		 
		 }
		 
		 
		 //Validate results using String comparison
		 public void validateResults(String valP1,String valP2)
		 {
			 if(valP1.equals(valP2))
			  {
				  System.out.println("Validation of"+DriverScript.valPoint1+ " is SUCCESS");
			  }
			  else
			  {
				  System.out.println("Validation of"+DriverScript.valPoint1+" is FAIL");  
			  }
		 }
		 //validate results using Boolen comparison
		 public void validateResults(Boolean valP1,Boolean valP2)
		 {
			 if(valP1 == valP2)
			  {
				  System.out.println("Validation of"+DriverScript.valPoint1+ " is SUCCESS");
			  }
			  else
			  {
				  System.out.println("Validation of"+DriverScript.valPoint1+" is FAIL");  
			  }
		 }
		 
		 
	}




